## ----setup, include=FALSE, message=FALSE, warning=FALSE------------------
knitr::opts_chunk$set(echo = TRUE,
                      message = FALSE, warning = FALSE, error = FALSE,
                      cache = FALSE)
options(digits = 4)

## ---- eval = FALSE-------------------------------------------------------
#  if (!requireNamespace("BiocManager", quietly = TRUE))
#      install.packages("BiocManager")
#  BiocManager::install(version = "3.10")
#  
#  BiocManager::install(c(
#                   'TENxPBMCData',    # dataset
#                   'DropletUtils',    # quality control
#                   'scater', 'scran', # normalization/downstream analysis/viz
#                   'iSEE',            # interactive viz (not run)
#                   'BiocParallel',    # faster computation
#                   'devtools',        # for installing cellassign
#                   'tidyr',           # data munging
#                   'tensorflow'))     # cellassign dependency
#  
#  ## optional for annotation section:
#  devtools::install_github('irrationone/cellassign') # automated annotation of cells

## ---- eval = FALSE-------------------------------------------------------
#      library(tidyr)
#      library(BiocParallel)
#      library(iSEE)
#      library(TENxPBMCData)
#      library(DropletUtils)
#      library(scater)
#      library(scran)

## ---- echo = FALSE-------------------------------------------------------
suppressPackageStartupMessages({
    library(tidyr)
    library(BiocParallel)
    library(iSEE)
    library(TENxPBMCData)
    library(DropletUtils)
    library(scater)
    library(scran)
})

## ------------------------------------------------------------------------
library(SingleCellExperiment)

## More realistic: read in your experimental design metadata
## If its per cell metadata, make sure it lines up with your
## counts matrix row IDs correctly
## my_metadata <- read.csv("my_metadata.csv") 

## Example data
ncells <- 100
my_counts_matrix <- matrix(rpois(20000, 5), ncol = ncells)
my_metadata <- data.frame(genotype = rep(c('A', 'B'), each = 50),
                          experiment_id = 'Experiment1')

## Construct the sce object manually
sce <- SingleCellExperiment(assays = list(counts = my_counts_matrix),
                            colData = my_metadata)

## Manually adding a variable that is the same across all cells
colData(sce) <- cbind(colData(sce), date = '2020-01-01')

sce

## ------------------------------------------------------------------------
library(TENxPBMCData)
sce <- TENxPBMCData('pbmc3k')

## ------------------------------------------------------------------------
sce

## ------------------------------------------------------------------------
rowData(sce)

## ------------------------------------------------------------------------
rownames(sce) <- rowData(sce)$Symbol_TENx

## ------------------------------------------------------------------------
## counts dupes from top to bottom
dupes <- duplicated(rownames(sce))

## keep all the not (!) duplicated genes
sce <- sce[!dupes, ]

## ------------------------------------------------------------------------
colnames(sce) <- sce$Barcode

## ---- fig.cap="Barcode rank (aka knee) plot showing log10-rank by log10-total counts relationship and calculated knee (horizontal line)."----
library(DropletUtils)

## Calculate the rank vs total counts per cell
br <- barcodeRanks(counts(sce))

## Create the knee plot
plot(log10(br$rank), log10(br$total))
abline(h = log10(metadata(br)$knee))

## Save the calculated knee from `barcodeRanks()`
knee <- log10(metadata(br)$knee)

## ------------------------------------------------------------------------
library(scater)

sce <- calculateQCMetrics(sce)

## ---- include=FALSE------------------------------------------------------
## quietly round QC metrics for better printing
colData(sce)[, -1:-12] <- apply(colData(sce)[, -1:-12], 2, round, digits = 2)

## ------------------------------------------------------------------------
colData(sce)[1:3, c("log10_total_features_by_counts", "log10_total_counts")]

## ---- fig.cap="Histogram of the log10 total counts with the calculated knee from above (vertical line)."----
hist(sce$log10_total_counts, breaks = 100)
abline(v = knee)

## ---- fig.cap="Smoothed scatter plot of the log10-total counts vs the log10-total features detected by counts with the calculated knee from above (vertical line)."----
smoothScatter(sce$log10_total_counts, sce$log10_total_features_by_counts, nbin = 250)
abline(v = knee)

## ---- eval=FALSE---------------------------------------------------------
#  ## not run
#  sce <- sce[, sce$log10_total_counts > knee]

## ------------------------------------------------------------------------
library(scran)

quick_clusters <- quickCluster(sce, use.ranks = FALSE)
sce <- computeSumFactors(sce, clusters = quick_clusters)

## ------------------------------------------------------------------------
sce <- scater::normalize(sce)

## ------------------------------------------------------------------------
assays(sce)

## ---- fig.cap="Mean-variance trend line fit by scran package trendVar() function."----
fit <- trendVar(sce, use.spikes = FALSE)

plot(fit$mean, fit$var)
curve(fit$trend(x), col = 'red', lwd = 2, add = TRUE)

## ------------------------------------------------------------------------
dec <- decomposeVar(sce, fit)
dec <- dec[order(dec$bio, decreasing = TRUE), ] # order by bio var

## ---- include=FALSE------------------------------------------------------
dec <- as.data.frame(apply(dec, 2, round, digits = 3))

## ------------------------------------------------------------------------
dec[1:5, ]

## ------------------------------------------------------------------------
## hvg_genes <- rownames(dec)[1:2000]
hvg_genes <- rownames(dec)[dec$bio > 0]

## ------------------------------------------------------------------------
metadata(sce)$hvg_genes <- hvg_genes
metadata(sce)$hvg_genes[1:10]

## ------------------------------------------------------------------------
sce <- runPCA(sce, ncomponents = 50,
              feature_set = hvg_genes)

## ------------------------------------------------------------------------
## access the attribute where percentVar is saved in reducedDim
pct_var_explained <- attr(reducedDim(sce, 'PCA'), 'percentVar')

plot(pct_var_explained) # elbow plot

## ---- fig.cap="UMAP plot."-----------------------------------------------
sce <- runUMAP(sce, use_dimred = 'PCA', n_dimred = 20)

plotUMAP(sce)

## ------------------------------------------------------------------------
set.seed(1234) # to make results reproducible
snng <- buildSNNGraph(sce, k = 50, d = 20)

## ------------------------------------------------------------------------
set.seed(1234)
snng_clusters <- igraph::cluster_louvain(snng)

## ------------------------------------------------------------------------
table(snng_clusters$membership)

## ---- fig.cap="UMAP plot showing calculated clusters."-------------------
colData(sce)$clusters <- as.factor(snng_clusters$membership)
plotUMAP(sce, colour_by = 'clusters')

## ------------------------------------------------------------------------
markers <- findMarkers(sce, clusters = colData(sce)$clusters,
                       subset.row = hvg_genes[1:250],
                       lfc = 1.5, direction = 'up', log.p = TRUE, 
                       BPPARAM = BiocParallel::MulticoreParam())

## ---- include=FALSE------------------------------------------------------
markers <- lapply(markers, function(x) {
    as.data.frame(apply(x, 2, round, digits = 3))
})

## ------------------------------------------------------------------------
markers[[1]][1:5, ]

## ---- fig.cap="Violin plots of CD3D expression across clusters."---------
plotExpression(sce, 'CD3D', x = 'clusters')

## ---- fig.cap="Heatmap showing top differentially expressed genes across the clusters."----
## grab the top 10 genes per cluster (e.g. within each list component)
genes <- lapply(markers, function(x) {
    rownames(x)[x$Top <= 10]
})

## uniqify the set of genes returned, after coercing to a vector
genes <- unique(unlist(genes))

plotHeatmap(sce, genes,
            colour_columns_by = "clusters",
            show_colnames = FALSE,
            clustering_method = 'ward.D2',
            fontsize_row = 6)

## ---- fig.cap="Various UMAP plots showing the expression of select cell-type specific genes."----
plotUMAP(sce, colour_by = "CD79A")
plotUMAP(sce, colour_by = "LYZ")
plotUMAP(sce, colour_by = "NKG7")
plotUMAP(sce, colour_by = "CD3D")

## ------------------------------------------------------------------------
anno <- data.frame(
    SYMBOL = c(
        'IL7R', 'CCR7', 'CD4', 'CD3D', 'CD3E',
        'CD14', 'LYZ',
        'MS4A1', 'CD79A', 'CD79B',
        'CD8A', 'CD8B', 'CD3D', 'CD3E',
        'GNLY', 'NKG7',
        'FCER1A', 'CST3', 'ITGAX'
    ),
    cell_type = c(
        rep('CD4 T cell', 5),
        rep('Monocyte', 2),
        rep('B cell', 3),
        rep('CD8 T cell', 4),
        rep('NK cell', 2),
        rep('Dendritic cell', 3)
    )
)

## ------------------------------------------------------------------------
## construct rho (binary marker matrix)
tmp <- tidyr::spread(anno, cell_type, cell_type)
rho <- ifelse(is.na(tmp[, -1]), 0, 1)
rownames(rho) <- tmp$SYMBOL

## remove entries that are not present in our dataset
rho <- rho[rownames(rho) %in% rownames(sce), ]

rho[1:3, ]

## ---- eval=FALSE---------------------------------------------------------
#  ## not run in vignette - results pulled from a prior run
#  ## devtools::install_github('Irrationone/cellassign')
#  library(cellassign)
#  library(tensorflow)
#  
#  set.seed(1234)
#  reticulate::py_set_seed(1234)
#  fit <- cellassign(sce[rownames(rho), ],
#                    marker_gene_info = rho,
#                    s = sizeFactors(sce))
#  
#  ## add cell type info into colData
#  colData(sce)$cellassign_type <- fit$cell_type

## ---- include=FALSE, eval=FALSE------------------------------------------
#  ## save cellassign results from one run to pull up for plot
#  saveRDS(fit$cell_type, 'inst/vignettes/cellassign_type.rds')

## ---- include=FALSE------------------------------------------------------
cellassign_type <- readRDS(file.path(system.file(package='OSCABioc2019', 'vignettes'), 'cellassign_type.rds'))
colData(sce)$cellassign_type <- cellassign_type

## ---- fig.cap="UMAP showing the results of automated label assignment as performed by cellassign."----
## plot the cellassign results on UMAP
plotUMAP(sce, colour_by = 'cellassign_type')

## ---- eval=FALSE---------------------------------------------------------
#  ## not run
#  library(iSEE)
#  iSEE(sce)

